<?php
    session_start();

    define ('URL', 'http://localhost/benerin_listrik/');
    define ('ASSET', URL . 'assets/');


    require_once "vendor/autoload.php";